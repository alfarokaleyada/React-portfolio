import React from 'react';

const AboutSection = () => {
    return (
        <section>
            <p>about section</p>
        </section>
    )
};

export default AboutSection;