import React from 'react';

const Main = () => {
    return (
        <section>
            <p>main</p>
        </section>
    )
};

export default Main;