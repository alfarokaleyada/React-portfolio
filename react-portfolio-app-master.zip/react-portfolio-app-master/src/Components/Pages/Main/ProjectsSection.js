import React from 'react';

const ProjectSection = () => {
    return (
        <section>
            <p>ProjectSection</p>
        </section>
    )
};

export default ProjectSection;