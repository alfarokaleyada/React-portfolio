import React from 'react';

const Contact = () => {
    return (
        <section>
            <p>contact</p>
        </section>
    )
};

export default Contact;