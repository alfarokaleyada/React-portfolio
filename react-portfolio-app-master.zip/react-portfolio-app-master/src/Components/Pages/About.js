import React from 'react';

const About = () => {
    return (
        <section>
            <p>about</p>
        </section>
    )
};

export default About;